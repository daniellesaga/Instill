# Instill

This is a group project.

CSIS 3175-001
Group 1 </br>
Danielle Saga</br>
Gabrielle Saga</br>
Lawanya Dasari</br>

</br><b>Skill Enhancer (Education Portal) - Instill</b>
</br>
User enters/fills out an initial resume in the app and a job end goal (e.g. fresh Douglas CS grad -> software engineer),  app will then assess the resume for the missing skills/skill set that would help strengthen the user's resume/profile
</br>

The app can give suggested skills (i.e. courses available via coursera/google etc) and can also give suggested contacts (i.e. Amazon software engineer who is also a Douglas CS grad) to connect and network with. Location services can also be added so that the user can see available job openings (i.e. user is in Vancouver so it will show all job openings in Vancouver/Greater VA)
</br>

<b>Extensions:</b>
Quick Look Preview - provide previews of documents/certs that the user has posted
Location Push Service - shares a user's location 
Share - will let the user post to social network services (i.e. linkedin, github, facebook jobs)
Event Merge - add multiple user's events in one calendar when link is clicked
