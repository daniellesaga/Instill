package com.instill.interfaces;

public interface DialogClickListeners {
    void onItemClick(Object item);
}