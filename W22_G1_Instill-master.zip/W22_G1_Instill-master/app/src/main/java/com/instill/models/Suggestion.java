package com.instill.models;

import java.io.Serializable;

public class Suggestion implements Serializable {

    public String title, link;

}