package com.instill.interfaces;

import android.view.View;

public interface RecyclerViewItemClick {
    void onItemClick(int position, View view);
}
